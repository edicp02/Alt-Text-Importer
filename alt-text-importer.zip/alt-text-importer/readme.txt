=== Alt Text Importer ===
Contributors: eduardpopa
Tags: alt text, images, media library, seo, accessibility
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Import alt text for your existing media images using a simple CSV file. Fast, lightweight, and SEO-friendly.

== Installation ==
1. Upload the plugin via WP Admin > Plugins > Add New > Upload Plugin
2. Activate the plugin
3. Go to Tools > Alt Text Importer and upload your CSV

== Changelog ==
= 1.0 =
* Initial release
