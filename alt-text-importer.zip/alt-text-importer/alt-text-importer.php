<?php
/**
 * Plugin Name: Alt Text Importer
 * Description: Import alt text for existing images using a CSV file (image_url, alt_text).
 * Version: 1.0
 * Author: Eduard Popa
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

add_action('admin_menu', function () {
    add_management_page('Alt Text Importer', 'Alt Text Importer', 'manage_options', 'alt-text-importer', 'alt_text_importer_page');
});

function alt_text_importer_page()
{
    if (!current_user_can('manage_options')) return;

    echo '<div class="wrap"><h1>Alt Text Importer</h1>';

    if (!empty($_FILES['alt_csv']['tmp_name'])) {
        $file = fopen($_FILES['alt_csv']['tmp_name'], 'r');
        $header = fgetcsv($file);
        $updated = 0;
        $not_found = 0;

        while ($row = fgetcsv($file)) {
            $data = array_combine($header, $row);
            $url = trim($data['image_url']);
            $alt = trim($data['alt_text']);

            $attachment_id = attachment_url_to_postid($url);
            if ($attachment_id) {
                update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt);
                $updated++;
            } else {
                $not_found++;
            }
        }
        fclose($file);

        echo "<div class='updated'><p><strong>$updated images updated.</strong><br>$not_found images not found.</p></div>";
    }

    echo '<form method="post" enctype="multipart/form-data">';
    echo '<input type="file" name="alt_csv" accept=".csv" required> ';
    echo '<input type="submit" class="button button-primary" value="Import Alt Text">';
    echo '</form></div>';
}
